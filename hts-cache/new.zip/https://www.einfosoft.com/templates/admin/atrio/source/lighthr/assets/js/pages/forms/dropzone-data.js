"use strict";
$(function () {
  //Dropzone
  Dropzone.options.frmFileUpload = {
    paramName: "file",
    maxFilesize: 10,
  };
});
