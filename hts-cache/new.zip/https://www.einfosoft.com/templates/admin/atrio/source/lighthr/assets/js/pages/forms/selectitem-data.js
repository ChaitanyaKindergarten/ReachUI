"use strict";
$(function () {
  $("select").formSelect();
});
